﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variant1
{
    internal class Person
    {
		private string name;
		private string surname;
		private DateTime bdate;

		public Person(string _name, string _surname, DateTime _bdate)
		{
            name = _name;
			surname = _surname;
			bdate = _bdate;
		}

		public Person()
        {
			name = "Chupapi";
			surname = "Munyanya";
			bdate = DateTime.Now;
        }

		public string get_name () { return name; }
		public string get_surname() { return surname; }
		public DateTime get_bdate() { return bdate; }
		
		public int Change 
		{ 
			get
            {
				return bdate.Year;
            } 
			set
            {
				bdate = DateTime.Now;
            } 
		}

        public override string ToString()
        {
            return name + " " + surname + " " + bdate;
        }

		public string ToShortString()
        {
			return name + " " + surname;
		}
    }
}
