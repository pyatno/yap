﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variant1
{
    internal class Exam
    {
        private string subject;
        private int mark;
        private DateTime date;

        public Exam(string _subject, int _mark, DateTime _date)
        {
            subject = _subject;
            mark = _mark;
            date = _date;
        }

        public Exam()
        {
            subject = "";
            mark = 2;
            date = DateTime.Now;
        }

        public override string ToString()
        {
            return subject + " " + mark + " " + date;
        }
    }
}
