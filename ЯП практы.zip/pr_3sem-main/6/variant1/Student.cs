﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variant1
{
    internal class Student
    {
        private Person person;
        private Education education;
        private int group;
        private Exam[] exam;

        public Student(Person _person, Education _education, int _group, Exam[] _exam)
        {
            person = _person;
            education = _education;
            group = _group;
            exam = _exam;
        }

        public Student()
        {
            person = null;
            education = 0;
            group = 0;
            exam = null;
        }
    }
}
