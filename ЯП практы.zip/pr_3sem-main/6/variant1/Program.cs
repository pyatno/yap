﻿using System;

namespace variant1
{
    class Program
    {
        static void Main(string[] Args)
        {
            Student student = new Student();
        }
    }
    public enum Education
    {
        Specialist = 0, Bachelor = 1, SecondEducation = 2
    }
}
