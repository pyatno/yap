﻿using System.IO;
using System.IO.Compression;

class Program
{
    static void CompressFile(string inFilename, string outFilename)
    {
        FileStream sourceFile = File.OpenRead(inFilename);
        FileStream destFile = File.Create(outFilename);

        GZipStream compStream = new GZipStream(destFile, CompressionMode.Compress);
        int theByte = sourceFile.ReadByte();
        while (theByte != -1)
        {
            compStream.WriteByte((byte)theByte);
            theByte = sourceFile.ReadByte();
        }
        compStream.Close();
        sourceFile.Close();
        destFile.Close();
    }

    static void UncompressFile(string inFilename, string outFilename)
    {
        FileStream sourceFile = File.OpenRead(outFilename);
        FileStream destinationFile = File.Create(inFilename);
        GZipStream compStream = new GZipStream(sourceFile, CompressionMode.Decompress);

        int theByte = compStream.ReadByte();
        while (theByte != -1)
        {
            destinationFile.WriteByte((byte)theByte);
            theByte = compStream.ReadByte();
        }
    }

    static void Main(string[] args)
    {
        CompressFile(@"c:\boot.ini", @"c:\boot.ini.gz");
        UncompressFile(@"c:\boot.ini.gz", @"c:\boot.ini.test");
    }
}
