﻿using System.Collections;
class Program
{
    static void Main(string[] args)
    {
        ArrayList arrayList = new ArrayList();

        arrayList.Add("First");
        arrayList.Add("Second");
        arrayList.Add("Third");
        arrayList.Add("Fourth");

        foreach (string item in arrayList)
        {
            Console.WriteLine("Unsorted: {0}", item);
        }

        arrayList.Sort();

        foreach (string item in arrayList)
        {
            System.Console.WriteLine("Sorted: {0}", item);
        }
    }
}
