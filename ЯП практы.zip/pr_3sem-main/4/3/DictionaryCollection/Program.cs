﻿using System.Collections;

class Program
{
    static void Main(string[] args)
    {
        Hashtable ht = new Hashtable();

        ht["0"] = "Zero";
        ht["1"] = "One";
        ht["2"] = "Two";
        ht["3"] = "Three";
        ht["4"] = "Four";
        ht["5"] = "Five";
        ht["6"] = "Six";
        ht["7"] = "Seven";
        ht["8"] = "Eight";
        ht["9"] = "Nine";

        string ourNumber = "888-555-1212";

        foreach (char c in ourNumber)
        {
            string digit = c.ToString();
            if (ht.ContainsKey(digit))
            {
                Console.WriteLine(ht[digit]);
            }
        }
    }
}
